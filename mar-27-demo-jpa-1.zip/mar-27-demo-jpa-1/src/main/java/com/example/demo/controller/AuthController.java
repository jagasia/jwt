package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.AuthRequest;
import com.example.demo.service.MyUserDetailsService;
import com.example.demo.util.JwtUtil;

class JwtToken
{
	String token;
	public JwtToken() {}
	public JwtToken(String token) {
		super();
		this.token = token;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	@Override
	public String toString() {
		return "JwtToken [token=" + token + "]";
	}
	
}


@RestController
public class AuthController {
	@Autowired
	private JwtUtil jwtUtil;
	@Autowired
	private MyUserDetailsService ms;

	@Autowired
	private AuthenticationManager authenticationManager;

	@PostMapping("/login")
	public JwtToken authenticate(@RequestBody AuthRequest ar) {
		System.out.println(ar);
		JwtToken jwt=new JwtToken();
		try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(ar.getUsername(), ar.getPassword()));
                  //login is successful 
                    String str=jwtUtil.generateToken(ar.getUsername());
                    
                    jwt.token=str;
                    return jwt;
            
        } catch (Exception ex) {
        	//login failed
        }
		jwt.token="Login Failed";
		return jwt;
	}
}
